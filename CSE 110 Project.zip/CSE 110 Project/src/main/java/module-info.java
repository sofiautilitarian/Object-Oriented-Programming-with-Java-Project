module com.currency_converter {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.currency_converter to javafx.fxml;
    exports com.currency_converter;
}