package com.currency_converter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;

public class skeleton1 implements Initializable {

    @FXML
    private Button button1;

    @FXML
    private ComboBox<String> countryName1;

    private String[] countries = {"Afghanistan","Bangladesh", "Bhutan", "India", "Maldives", "Nepal", "Pakistan", "Sri Lanka", "USA", "Europe"};//this array is used to populate the comboboxes and add the elements of the array to the comboboxes
    @FXML
    private ComboBox<String> countryName2;//combobox 2

    @FXML
    private Label label1; //this is the label used at the end of SceneBuilder to display the output

    @FXML
    private TextField textf1; //used to take user input

    DecimalFormat df = new DecimalFormat("#.##");

    double currency;
    String countryname1, countryname2;

    @FXML
    void convert() {
        convert();
    }

    @FXML
    void convert(ActionEvent event) {

        try {
            countryname1 = countryName1.getValue();//combobox 1
            countryname2 = countryName2.getValue();//combobox 2
            currency = Double.parseDouble(textf1.getText());//converts string to double
            double ff;
            //Bangladeshi Taka to Others:
            if (countryname1=="Bangladesh") {
                if (countryname2 == "Europe") {
                    ff = currency * 0.010;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + ff + " Euro");
                } else if (countryname2 == "Afghanistan") {
                    ff = currency * 1.22;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + ff + " Afghan Afghani");
                } else if (countryname2 == "USA") {
                    ff = currency * 0.012;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + ff + " US Dollar");
                } else if (countryname2 == "Bhutan") {
                    ff = currency * 0.86;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + ff + " Bhutan Currency");
                } else if (countryname2 == "India") {
                    ff = currency * 0.86;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + ff + " Indian Rupee");
                } else if (countryname2 == "Maldives") {
                    ff = currency * 0.18;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + ff + " Maldivian Rufiyaa");
                } else if (countryname2 == "Nepal") {
                    ff = currency * 1.38;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + ff + " Nepalese Rupee");
                } else if (countryname2 == "Pakistan") {
                    ff = currency * 2.05;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + df.format(ff) + " Pakistani Rupee");
                } else if (countryname2 == "Sri Lanka") {
                    ff = currency * 2.36;
                    //ff += currency;
                    label1.setText("Bangladeshi Taka " + currency + " = " + ff + " Sri Lankan Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }
            //Indian Rupee to Others:
            else if (countryname1=="India") {
                if (countryname2 == "Europe") {
                    ff = currency * 0.012;
                    // ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + ff + " Euro");
                } else if (countryname2 == "Afghanistan") {
                    ff = currency * 1.41;
                    //ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + ff + " Afghan Afghani");
                } else if (countryname2 == "USA") {
                    ff = currency * 0.013;
                    // ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + ff + " US Dollar");
                } else if (countryname2 == "Bhutan") {
                    ff = currency * 1;
                    // ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + ff + " Bhutan Currency");
                } else if (countryname2 == "Bangladesh") {
                    ff = currency * 1.16;
                    //ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + df.format(ff) + " Bangladeshi Taka");
                } else if (countryname2 == "Maldives") {
                    ff = currency * 0.21;
                    // ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + ff + " Maldivian Rufiyaa");
                } else if (countryname2 == "Nepal") {
                    ff = currency * 1.60;
                    //ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + ff + " Nepalese Rupee");
                } else if (countryname2 == "Pakistan") {
                    ff = currency * 2.39;
                    //ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + ff + " Pakistani Rupee");
                } else if (countryname2 == "Sri Lanka") {
                    ff = currency * 2.73;
                    //ff += currency;
                    label1.setText("Indian Rupee " + currency + " = " + ff + " Sri Lankan Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit ");
                }
            }
            //Pakistani Rupee to others:
            else  if (countryname1=="Pakistan") {
                if (countryname2 == "Europe") {
                    ff = currency * 0.0050;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + ff + " Euro");
                } else if (countryname2 == "Afghanistan") {
                    ff = currency * 0.59;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + ff + " Afghan Afghani");
                } else if (countryname2 == "USA") {
                    ff = currency * 0.0056;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + df.format(ff) + " US Dollar");
                } else if (countryname2 == "Bhutan") {
                    ff = currency * 0.42;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + ff + " Bhutan Currency");
                } else if (countryname2 == "Bangladesh") {
                    ff = currency * 0.49;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + ff + " Bangladeshi Taka");
                } else if (countryname2 == "Maldives") {
                    ff = currency * 0.087;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + ff + " Maldivian Rufiyaa");
                } else if (countryname2 == "Nepal") {
                    ff = currency * 0.67;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + ff + " Nepalese Rupee");
                } else if (countryname2 == "India") {
                    ff = currency * 0.42;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + ff + " Indian Rupee");
                } else if (countryname2 == "Sri Lanka") {
                    ff = currency * 1.15;
                    //ff += currency;
                    label1.setText("Pakistani Rupee " + currency + " = " + df.format(ff) + " Sri Lankan Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }
            //Sri Lanka Rupee to others:
            else if (countryname1=="Sri Lanka") {
                if (countryname2 == "Europe") {
                    ff = currency * 0.0043;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + ff + " Euro");
                } else if (countryname2 == "Afghanistan") {
                    ff = currency * 0.52;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + ff + " Afghan Afghani");
                } else if (countryname2 == "USA") {
                    ff = currency * 0.0049;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + ff + " US Dollar");
                } else if (countryname2 == "Bhutan") {
                    ff = currency * 0.37;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + ff + " Bhutan Currency");
                } else if (countryname2 == "Bangladesh") {
                    ff = currency * 0.42;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + ff + " Bangladeshi Taka");
                } else if (countryname2 == "Maldives") {
                    ff = currency * 0.076;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + ff + " Maldivian Rufiyaa");
                } else if (countryname2 == "Nepal") {
                    ff = currency * 0.59;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + ff + " Nepalese Rupee");
                } else if (countryname2 == "India") {
                    ff = currency * 0.37;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + ff + " Indian Rupee");
                } else if (countryname2 == "Pakistan") {
                    ff = currency * 0.87;
                    //ff += currency;
                    label1.setText("Sri Lankan Rupee " + currency + " = " + df.format(ff) + " Pakistani Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }

            //Nepalese Rupee to others:
            else if (countryname1=="Nepal") {
                if (countryname2 == "Europe") {
                    ff = currency * 0.0074;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " Euro");
                } else if (countryname2 == "Afghanistan") {
                    ff = currency * 0.88;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " Afghan Afghani");
                } else if (countryname2 == "USA") {
                    ff = currency * 0.0084;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " US Dollar");
                } else if (countryname2 == "Bhutan") {
                    ff = currency * 0.63;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " Bhutan Currency");
                } else if (countryname2 == "Bangladesh") {
                    ff = currency * 0.72;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " Bangladeshi Taka");
                } else if (countryname2 == "Maldives") {
                    ff = currency * 0.13;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " Maldivian Rufiyaa");
                } else if (countryname2 == "Sri Lanka") {
                    ff = currency * 1.71;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " Sri Lankan Rupee");
                } else if (countryname2 == "India") {
                    ff = currency * 0.62;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " Indian Rupee");
                } else if (countryname2 == "Pakistan") {
                    ff = currency * 1.49;
                    //ff += currency;
                    label1.setText("Nepalese Rupee " + currency + " = " + ff + " Pakistani Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }

            //Maldivian Rufiyaa to others:
            else if (countryname1=="Maldives") {
                if (countryname2 == "Europe") {
                    ff = currency * 0.057;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + ff + " Euro");
                } else if (countryname2 == "Afghanistan") {
                    ff = currency * 6.80;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + ff + " Afghan Afghani");
                } else if (countryname2 == "USA") {
                    ff = currency * 0.065;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + ff + " US Dollar");
                } else if (countryname2 == "Bhutan") {
                    ff = currency * 4.81;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + df.format(ff) + " Bhutan Currency");
                } else if (countryname2 == "Bangladesh") {
                    ff = currency * 5.56;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + ff + " Bangladeshi Taka");
                } else if (countryname2 == "Nepal") {
                    ff = currency * 7.69;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + ff + " Nepalese Rupee ");
                } else if (countryname2 == "Sri Lanka") {
                    ff = currency * 13.13;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + ff + " Sri Lankan Rupee");
                } else if (countryname2 == "India") {
                    ff = currency * 4.81;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + df.format(ff) + " Indian Rupee");
                } else if (countryname2 == "Pakistan") {
                    ff = currency * 11.47;
                    //ff += currency;
                    label1.setText("Maldivian Rufiyaa " + currency + " = " + ff + " Pakistani Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }

            //Bhutan Currency to others:
            else if (countryname1=="Bhutan") {
                if (countryname2 == "Europe") {
                    ff = currency * 0.012;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " Euro");
                } else if (countryname2 == "Afghanistan") {
                    ff = currency * 1.41;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " Afghan Afghani");
                } else if (countryname2 == "USA") {
                    ff = currency * 0.013;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " US Dollar");
                } else if (countryname2 == "Maldives") {
                    ff = currency * 0.21;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " Maldivian Rufiyaa ");
                } else if (countryname2 == "Bangladesh") {
                    ff = currency * 1.16;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " Bangladeshi Taka");
                } else if (countryname2 == "Nepal") {
                    ff = currency * 1.60;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " Nepalese Rupee ");
                } else if (countryname2 == "Sri Lanka") {
                    ff = currency * 2.73;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " Sri Lankan Rupee");
                } else if (countryname2 == "India") {
                    ff = currency * 1;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " Indian Rupee");
                } else if (countryname2 == "Pakistan") {
                    ff = currency * 2.38;
                    //ff += currency;
                    label1.setText("Bhutan Currency " + currency + " = " + ff + " Pakistani Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }

            //   Afghan Afghani to others:
            else if (countryname1=="Afghanistan") {
                if (countryname2 == "Europe") {
                    ff = currency * 0.0084;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + ff + " Euro");
                } else if (countryname2 == "Bhutan") {
                    ff = currency * 0.71;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + ff + " Bhutan Currency ");
                } else if (countryname2 == "USA") {
                    ff = currency * 0.0095;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + ff + " US Dollar");
                } else if (countryname2 == "Maldives") {
                    ff = currency * 0.15;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + ff + " Maldivian Rufiyaa ");
                } else if (countryname2 == "Bangladesh") {
                    ff = currency * 0.82;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + ff + " Bangladeshi Taka");
                } else if (countryname2 == "Nepal") {
                    ff = currency * 1.13;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + df.format(ff) + " Nepalese Rupee ");
                } else if (countryname2 == "Sri Lanka") {
                    ff = currency * 1.93;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + ff + " Sri Lankan Rupee");
                } else if (countryname2 == "India") {
                    ff = currency * 0.71;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + ff + " Indian Rupee");
                } else if (countryname2 == "Pakistan") {
                    ff = currency * 1.69;
                    //ff += currency;
                    label1.setText("Afghan Afghani " + currency + " = " + ff + " Pakistani Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }

            //US Dollar to others:
            else  if (countryname1=="USA"){
                if(countryname2=="Europe"){
                    ff = currency*0.88;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Euro");
                }
                else if(countryname2=="Bhutan"){
                    ff = currency*74.31;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Bhutan Currency ");
                }
                else if(countryname2=="Afghanistan"){
                    ff = currency*105.00;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Afghan Afghani ");
                }
                else if(countryname2=="Maldives"){
                    ff = currency*15.45;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Maldivian Rufiyaa ");
                }
                else if(countryname2=="Bangladesh"){
                    ff = currency*85.94;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Bangladeshi Taka");
                }
                else if(countryname2=="Nepal"){
                    ff = currency*118.90;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Nepalese Rupee ");
                }
                else if(countryname2=="Sri Lanka"){
                    ff = currency*202.89;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Sri Lankan Rupee");
                }
                else if(countryname2=="India"){
                    ff = currency*74.23;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Indian Rupee");
                }
                else if(countryname2=="Pakistan"){
                    ff = currency*177.10;
                    //ff+=currency;
                    label1.setText("US Dollar "+ currency+" = "+ff+" Pakistani Rupee");
                }
                else{
                    label1.setText("You entered "+currency+"\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }

            //   Euro to others:
            else if (countryname1=="Europe") {
                if (countryname2 == "USA") {
                    ff = currency * 1.14;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + df.format(ff) + " US Dollar ");
                } else if (countryname2 == "Bhutan") {
                    ff = currency * 84.39;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + ff + " Bhutan Currency ");
                } else if (countryname2 == "Afghanistan") {
                    ff = currency * 119.22;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + ff + " Afghan Afghani ");
                } else if (countryname2 == "Maldives") {
                    ff = currency * 17.55;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + ff + " Maldivian Rufiyaa ");
                } else if (countryname2 == "Bangladesh") {
                    ff = currency * 97.58;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + ff + " Bangladeshi Taka");
                } else if (countryname2 == "Nepal") {
                    ff = currency * 135.03;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + ff + " Nepalese Rupee ");
                } else if (countryname2 == "Sri Lanka") {
                    ff = currency * 230.37;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + ff + " Sri Lankan Rupee");
                } else if (countryname2 == "India") {
                    ff = currency * 84.28;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + ff + " Indian Rupee");
                } else if (countryname2 == "Pakistan") {
                    ff = currency * 201.12;
                    //ff += currency;
                    label1.setText("Euro " + currency + " = " + ff + " Pakistani Rupee");
                } else {
                    label1.setText("You entered " + currency + "\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
                }
            }
            else{
                label1.setText("You entered "+currency+"\nPlease choose different countries from the boxes above.\nThen, enter a currency, and click submit");
            }

        }
        catch (NumberFormatException e) {
            label1.setText("Please enter numbers only");
        }
        catch (Exception eh){
            label1.setText("Error");
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        countryName1.getItems().addAll(countries);
        countryName2.getItems().addAll(countries);
        //countryName1.setOnAction(this::convert);
        //countryName2.setOnAction(this::convert);

    }


}
