package com.currency_converter;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Welcome to currency converter! You can convert currency from SAARC countries to Euro and Dollar and vice versa");
        stage.setScene(scene);
        stage.show();
    }
    //driver class,  Java driver class. This is where the FXML is loaded, stage is created, then a scene is inserted, then I show the stage. The program runs from here.
//we did it using SceneBuilder
    //variable declaration fx:id
    //
    public static void main(String[] args) {
        //shows polymorphism
        skeleton1 skeleton = new HelloController();
        //implicit casting;
        HelloController control = (HelloController)skeleton;//upcasting
        launch();//

    }
}